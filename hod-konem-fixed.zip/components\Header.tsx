'use client';

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase, signInWithGoogle } from '@/lib/supabase';
import { User } from '@supabase/supabase-js';
import Image from 'next/image';
import Link from 'next/link';
import PlayerSidebar from './PlayerSidebar';
import NicknameModal from './NicknameModal';

interface Profile {
  username: string;
  avatar_url: string;
  elo_rating: number;
  rank: string;
}

export default function Header() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showNickname, setShowNickname] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Initial load from localStorage (instant)
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        setUser(session.user);
        loadProfile(session.user.id);
      } else {
        setLoading(false);
      }
    });

    // Listen for auth changes (login/logout)
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      const u = session?.user ?? null;
      setUser(u);
      if (u) {
        loadProfile(u.id);
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const loadProfile = async (userId: string) => {
    try {
      const { data } = await supabase
        .from('profiles')
        .select('username, avatar_url, elo_rating, rank')
        .eq('id', userId)
        .single();
      if (data) {
        setProfile(data);
        if (!data.username || data.username.includes('@') || data.username.length < 2) {
          setShowNickname(true);
        }
      }
    } catch {}
    setLoading(false);
  };

  const handleNicknameComplete = (nickname: string) => {
    setProfile((p) => p ? { ...p, username: nickname } : null);
    setShowNickname(false);
  };

  return (
    <>
      <motion.header
        className="fixed top-0 left-0 right-0 z-40 px-3 py-2"
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
      >
        <div
          className="max-w-7xl mx-auto flex items-center justify-between rounded-2xl px-4 py-2.5"
          style={{
            background: 'rgba(15, 23, 42, 0.92)',
            backdropFilter: 'blur(20px)',
            border: '1px solid rgba(245, 158, 11, 0.2)',
            boxShadow: '0 4px 30px rgba(0,0,0,0.3)',
          }}
        >
          {/* Left: Burger + Logo */}
          <div className="flex items-center gap-3">
            <motion.button
              onClick={() => setSidebarOpen(true)}
              className="flex flex-col gap-1 p-2 rounded-xl hover:bg-white/8 transition-colors"
              whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
            >
              <span className="w-5 h-0.5 bg-white/60 rounded-full block" />
              <span className="w-5 h-0.5 bg-white/60 rounded-full block" />
              <span className="w-5 h-0.5 bg-white/60 rounded-full block" />
            </motion.button>

            <Link href="/" className="flex items-center gap-2">
              <span className="text-2xl select-none" style={{ filter: 'drop-shadow(0 0 8px rgba(245,158,11,0.7))' }}>♞</span>
              <div className="hidden sm:block">
                <div className="text-base font-bold leading-tight" style={{ fontFamily: "'Playfair Display', serif", color: '#f59e0b' }}>Ход Конём</div>
                <div className="text-xs text-white/35 leading-tight">Шахматная школа</div>
              </div>
            </Link>
          </div>

          {/* Right */}
          <div className="flex items-center gap-2">
            {/* Profile or Login — only show after loading */}
            {!loading && (
              user && profile ? (
                <motion.button
                  onClick={() => setSidebarOpen(true)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-white/10 hover:border-yellow-400/30 hover:bg-white/5 transition-all"
                  whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }}
                >
                  <div className="w-7 h-7 rounded-full overflow-hidden border border-yellow-500/40 flex-shrink-0">
                    {profile.avatar_url ? (
                      <Image src={profile.avatar_url} alt={profile.username} width={28} height={28} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-yellow-500/20 flex items-center justify-center text-yellow-400 text-xs font-bold">
                        {profile.username?.[0]?.toUpperCase() || '?'}
                      </div>
                    )}
                  </div>
                  <div className="hidden sm:block text-left">
                    <div className="text-xs font-semibold text-white/90 leading-tight">{profile.username}</div>
                    <div className="text-xs text-yellow-400 font-bold leading-tight">ELO {profile.elo_rating}</div>
                  </div>
                </motion.button>
              ) : !user ? (
                <motion.button
                  onClick={signInWithGoogle}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl font-semibold text-sm border border-white/15 text-white/80 hover:bg-white/8 transition-all"
                  whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }}
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                  <span className="hidden sm:inline">Войти</span>
                </motion.button>
              ) : null
            )}

            {/* WhatsApp */}
            <motion.a
              href={process.env.NEXT_PUBLIC_WHATSAPP_URL || 'https://wa.me/+77751405299'}
              target="_blank" rel="noopener noreferrer"
              className="pulse-gold flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold text-xs sm:text-sm text-black whitespace-nowrap flex-shrink-0"
              style={{ background: 'linear-gradient(135deg, #f59e0b, #d97706)' }}
              whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.97 }}
            >
              <span>📱</span>
              <span className="hidden md:inline">Запишитесь на бесплатный урок</span>
              <span className="md:hidden">Урок</span>
            </motion.a>
          </div>
        </div>
      </motion.header>

      <PlayerSidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <AnimatePresence>
        {showNickname && user && (
          <NicknameModal userId={user.id} onComplete={handleNicknameComplete} />
        )}
      </AnimatePresence>
    </>
  );
}
